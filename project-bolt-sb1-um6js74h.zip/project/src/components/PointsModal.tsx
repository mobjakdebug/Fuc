import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Star } from 'lucide-react';
import { useStore } from '../store';
import { format } from 'date-fns';

interface PointsModalProps {
  onClose: () => void;
}

const PointsModal: React.FC<PointsModalProps> = ({ onClose }) => {
  const { points, setPoints, lastDailyBonus, setLastDailyBonus, usedCodes, addUsedCode } = useStore();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleDailyBonus = () => {
    const today = format(new Date(), 'yyyy-MM-dd');
    if (lastDailyBonus === today) {
      setError('شما امروز جایزه روزانه خود را دریافت کرده‌اید');
      return;
    }

    const bonus = Math.floor(Math.random() * 16) + 5; // Random number between 5 and 20
    setPoints(points + bonus);
    setLastDailyBonus(today);
    setSuccess(`تبریک! ${bonus} امتیاز دریافت کردید`);
  };

  const handleCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (usedCodes.includes(code)) {
      setError('این کد قبلاً استفاده شده است');
      return;
    }

    let bonus = 0;
    switch (code) {
      case 'iamartin':
        bonus = 100;
        break;
      case 'iiamartin':
        bonus = 200;
        break;
      case 'iiiamartin':
        bonus = 5000;
        break;
      default:
        setError('کد نامعتبر است');
        return;
    }

    setPoints(points + bonus);
    addUsedCode(code);
    setSuccess(`تبریک! ${bonus} امتیاز دریافت کردید`);
    setCode('');
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-xl shadow-xl p-6 max-w-md w-full relative"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-6">امتیازات</h2>

        <div className="space-y-6">
          <div className="bg-yellow-50 p-4 rounded-lg flex items-center justify-between">
            <span className="text-lg font-medium text-yellow-700">امتیاز فعلی</span>
            <div className="flex items-center text-yellow-600">
              <Star className="w-5 h-5 mr-2" />
              <span className="text-xl font-bold">{points}</span>
            </div>
          </div>

          <div>
            <button
              onClick={handleDailyBonus}
              disabled={lastDailyBonus === format(new Date(), 'yyyy-MM-dd')}
              className="btn btn-primary w-full"
            >
              دریافت جایزه روزانه
            </button>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-medium mb-4">خرید امتیاز</h3>
            <div className="space-y-3">
              <button
                onClick={() => window.location.href = 'mailto:arexit@gmail.com?subject=خرید بسته 100 امتیازی&body=درخواست خرید بسته 100 امتیازی به مبلغ 10,000 تومان'}
                className="btn btn-secondary w-full text-right"
              >
                ۱۰۰ امتیاز - ۱۰,۰۰۰ تومان
              </button>
              <button
                onClick={() => window.location.href = 'mailto:arexit@gmail.com?subject=خرید بسته 200 امتیازی&body=درخواست خرید بسته 200 امتیازی به مبلغ 19,000 تومان'}
                className="btn btn-secondary w-full text-right"
              >
                ۲۰۰ امتیاز - ۱۹,۰۰۰ تومان
              </button>
              <button
                onClick={() => window.location.href = 'mailto:arexit@gmail.com?subject=خرید بسته 5000 امتیازی&body=درخواست خرید بسته 5000 امتیازی به مبلغ 99,000 تومان'}
                className="btn btn-secondary w-full text-right"
              >
                ۵۰۰۰ امتیاز - ۹۹,۰۰۰ تومان
              </button>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-medium mb-4">فعال‌سازی کد</h3>
            <form onSubmit={handleCodeSubmit}>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="کد را وارد کنید"
                className="input mb-2"
              />
              <button type="submit" className="btn btn-primary w-full">
                فعال‌سازی
              </button>
            </form>
          </div>

          {error && (
            <div className="bg-red-50 text-red-700 p-3 rounded-lg">
              {error}
            </div>
          )}

          {success && (
            <div className="bg-green-50 text-green-700 p-3 rounded-lg">
              {success}
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default PointsModal;