import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';

const OnboardingForm = () => {
  const { t } = useTranslation();
  const setUser = useStore((state) => state.setUser);
  
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    conditions: [''],
    category: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUser({
      name: formData.name,
      age: parseInt(formData.age),
      conditions: formData.conditions.filter(c => c.trim() !== ''),
      category: formData.category
    });
  };

  const addCondition = () => {
    setFormData(prev => ({
      ...prev,
      conditions: [...prev.conditions, '']
    }));
  };

  const updateCondition = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      conditions: prev.conditions.map((c, i) => i === index ? value : c)
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full"
      >
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          {t('welcome')}
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              نام و نام خانوادگی
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              className="input"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              سن
            </label>
            <input
              type="number"
              required
              min="0"
              max="120"
              value={formData.age}
              onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
              className="input"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              بیماری‌ها
            </label>
            {formData.conditions.map((condition, index) => (
              <div key={index} className="mb-2">
                <input
                  type="text"
                  value={condition}
                  onChange={(e) => updateCondition(index, e.target.value)}
                  className="input"
                  placeholder="نام بیماری"
                />
              </div>
            ))}
            <button
              type="button"
              onClick={addCondition}
              className="btn btn-secondary mt-2"
            >
              + افزودن بیماری
            </button>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              دسته‌بندی
            </label>
            <select
              required
              value={formData.category}
              onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
              className="input"
            >
              <option value="">انتخاب کنید</option>
              <option value="general">عمومی</option>
              <option value="heart">قلب و عروق</option>
              <option value="neuro">مغز و اعصاب</option>
              <option value="ortho">استخوان و مفاصل</option>
              <option value="eye">چشم</option>
              <option value="women">زنان</option>
              <option value="lab">آزمایشگاه</option>
              <option value="kidney">کلیه</option>
              <option value="dental">دندانپزشکی</option>
              <option value="psych">روانشناسی</option>
            </select>
          </div>
          
          <button type="submit" className="btn btn-primary w-full">
            ثبت اطلاعات
          </button>
        </form>
      </motion.div>
    </div>
  );
};

export default OnboardingForm;