import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';

const DoctorChat = () => {
  const { t } = useTranslation();

  return (
    <div className="h-[calc(100vh-5rem)] bg-gray-50">
      <div className="grid grid-cols-4 h-full">
        {/* Doctors List */}
        <div className="col-span-1 bg-white border-l">
          <div className="p-4">
            <h2 className="text-lg font-semibold mb-4">پزشکان</h2>
            {/* Doctor list items will be added here */}
          </div>
        </div>

        {/* Chat Area */}
        <div className="col-span-3 flex flex-col">
          <div className="flex-1 p-4">
            {/* Chat messages will be added here */}
          </div>
          
          <div className="p-4 border-t bg-white">
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="پیام خود را بنویسید..."
                className="input flex-1"
              />
              <button className="btn btn-primary">
                ارسال
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorChat;