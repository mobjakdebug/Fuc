import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useStore } from '../store';

interface ProfileModalProps {
  onClose: () => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ onClose }) => {
  const { user, setUser } = useStore();
  
  const [formData, setFormData] = React.useState({
    name: user?.name || '',
    age: user?.age || '',
    conditions: user?.conditions || [''],
    category: user?.category || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUser({
      name: formData.name,
      age: parseInt(String(formData.age)),
      conditions: formData.conditions.filter(c => c.trim() !== ''),
      category: formData.category
    });
    onClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-xl shadow-xl p-6 max-w-md w-full relative"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-6">حساب کاربری</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              نام و نام خانوادگی
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              className="input"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              سن
            </label>
            <input
              type="number"
              required
              min="0"
              max="120"
              value={formData.age}
              onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
              className="input"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              دسته‌بندی
            </label>
            <select
              required
              value={formData.category}
              onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
              className="input"
            >
              <option value="">انتخاب کنید</option>
              <option value="general">عمومی</option>
              <option value="heart">قلب و عروق</option>
              <option value="neuro">مغز و اعصاب</option>
              <option value="ortho">استخوان و مفاصل</option>
              <option value="eye">چشم</option>
              <option value="women">زنان</option>
              <option value="lab">آزمایشگاه</option>
              <option value="kidney">کلیه</option>
              <option value="dental">دندانپزشکی</option>
              <option value="psych">روانشناسی</option>
            </select>
          </div>

          <button type="submit" className="btn btn-primary w-full">
            ذخیره تغییرات
          </button>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default ProfileModal;