import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  fa: {
    translation: {
      welcome: 'به سیستم مشاوره پزشکی خوش آمدید',
      loading: 'در حال بارگذاری...',
      madeIn: 'ساخته شده در علامه حلی ۹',
      settings: 'تنظیمات',
      profile: 'حساب کاربری',
      points: 'امتیازات',
      dailyBonus: 'جایزه روزانه',
      doctors: {
        general: 'پزشک عمومی',
        heart: 'متخصص قلب و عروق',
        neuro: 'متخصص مغز و اعصاب',
        ortho: 'متخصص استخوان و ستون فقرات',
        eye: 'متخصص چشم',
        women: 'متخصص بانوان',
        lab: 'متخصص آزمایشگاه',
        kidney: 'متخصص کلیه',
        pharmacy: 'داروخانه',
        dental: 'دندانپزشک',
        psych: 'روانشناس'
      }
    }
  },
  en: {
    translation: {
      // English translations
    }
  },
  ar: {
    translation: {
      // Arabic translations
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'fa',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;