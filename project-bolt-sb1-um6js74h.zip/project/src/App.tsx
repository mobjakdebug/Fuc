import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, User, Star, MessageSquare } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import './i18n';
import { useStore } from './store';
import LoadingScreen from './components/LoadingScreen';
import OnboardingForm from './components/OnboardingForm';
import DoctorChat from './components/DoctorChat';
import SettingsModal from './components/SettingsModal';
import ProfileModal from './components/ProfileModal';
import PointsModal from './components/PointsModal';

function App() {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showPoints, setShowPoints] = useState(false);
  
  const { user, points, setPoints } = useStore();

  useEffect(() => {
    // Simulate loading screen
    setTimeout(() => setLoading(false), 2500);
  }, []);

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <OnboardingForm />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <Settings className="w-6 h-6" />
            </button>
          </div>
          
          <div className="flex items-center space-x-6">
            <button
              onClick={() => setShowPoints(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-yellow-100 rounded-full"
            >
              <Star className="w-5 h-5 text-yellow-600" />
              <span className="font-medium text-yellow-700">{points}</span>
            </button>
            
            <button
              onClick={() => setShowProfile(true)}
              className="flex items-center space-x-2"
            >
              <span className="font-medium">{user.name}</span>
              <User className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <DoctorChat />
      </main>

      <AnimatePresence>
        {showSettings && (
          <SettingsModal onClose={() => setShowSettings(false)} />
        )}
        {showProfile && (
          <ProfileModal onClose={() => setShowProfile(false)} />
        )}
        {showPoints && (
          <PointsModal onClose={() => setShowPoints(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;