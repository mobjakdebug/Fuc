import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  name: string;
  age: number;
  conditions: string[];
  category: string;
}

interface State {
  user: User | null;
  points: number;
  language: string;
  theme: 'light' | 'dark';
  unlockedDoctors: string[];
  usedCodes: string[];
  lastDailyBonus: string | null;
  setUser: (user: User) => void;
  setPoints: (points: number) => void;
  setLanguage: (language: string) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  unlockDoctor: (doctorId: string) => void;
  addUsedCode: (code: string) => void;
  setLastDailyBonus: (date: string) => void;
}

export const useStore = create<State>()(
  persist(
    (set) => ({
      user: null,
      points: 100,
      language: 'fa',
      theme: 'light',
      unlockedDoctors: ['general'],
      usedCodes: [],
      lastDailyBonus: null,
      setUser: (user) => set({ user }),
      setPoints: (points) => set({ points }),
      setLanguage: (language) => set({ language }),
      setTheme: (theme) => set({ theme }),
      unlockDoctor: (doctorId) =>
        set((state) => ({
          unlockedDoctors: [...state.unlockedDoctors, doctorId],
        })),
      addUsedCode: (code) =>
        set((state) => ({
          usedCodes: [...state.usedCodes, code],
        })),
      setLastDailyBonus: (date) => set({ lastDailyBonus: date }),
    }),
    {
      name: 'medical-app-storage',
    }
  )
);